def title_name(names:list):
    return_list = [x.title() for x in names]
    return return_list